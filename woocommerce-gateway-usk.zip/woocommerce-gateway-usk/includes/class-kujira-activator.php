<?php

/**
 * Fired during plugin activation
 *
 * @link       https://github.com/codehans
 * @since      1.0.0
 *
 * @package    Kujira
 * @subpackage Kujira/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Kujira
 * @subpackage Kujira/includes
 * @author     codehans <94654388+codehans@users.noreply.github.com>
 */
class Kujira_Activator
{

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate()
	{
	}
}
